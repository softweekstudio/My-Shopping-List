MY SHOPPING LIST — PWA PACKAGE

Files to upload to the SAME GitHub Pages folder:
- index.html
- manifest.webmanifest
- sw.js
- icon.png
- icon-192.png
- icon-512.png

IMPORTANT:
- Keep "index.html" exactly lowercase.
- Do not rename the icon files.
- Do not put the files in different folders.
- The existing shopping-list design and functions are preserved.
- The manifest makes the site installable as a PWA.
- The service worker adds offline caching after the first successful load.

GITHUB PAGES:
Upload all five files to the same folder where index.html is published.
You do NOT need to create a new GitHub Pages site.

NOTE:
The app's shopping data is stored locally in the browser/device. The PWA package does not add cloud synchronization.
